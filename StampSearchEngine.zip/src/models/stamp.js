
const StampModel = {
    title: "",
    country: "",
    year: 0,
    stampNumber: "",
    faceValue: "",
    info: "",
    catalogName: "",
    catalogNumber: "",
    catalogYear: 0,
    price: "",
    scottNumber: "",
    verientNumber: "",
}