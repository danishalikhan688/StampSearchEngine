const ErrorType = {
    undefined: -1,
    success: 1,
    failure: 2,
    warning: 3,
    issue: 4,
}

export default ErrorType