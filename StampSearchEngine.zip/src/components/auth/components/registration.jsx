 
const RegistrationForm = (props) => {
  
  return ( 
    <div className="auth-body ">
      RegistrationForm
  </div> 
  );
};

export default RegistrationForm;
