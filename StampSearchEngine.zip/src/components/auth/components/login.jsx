import React  from "react"; 
var temp = {};
const LoginForm = (props) => { 
  return (
    <div className="auth-body ">
      login
    </div>
  );
};

export default LoginForm;
