export const MenuClick = 'MenuClick'
export const CampaignData = 'CampaignData'
export const ChangeDoctorStatus = 'ChangeDoctorStatus'