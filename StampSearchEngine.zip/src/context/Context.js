import { createContext } from "react"
// @Context use globally to access the state of components
const Context = createContext();
export default Context;