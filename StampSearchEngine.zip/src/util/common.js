export const globalVars = {
    urls: {
        baseURL: "http://localhost:5000/",
    }
};
